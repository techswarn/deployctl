def hello():
    print("Hello setup.py!")
